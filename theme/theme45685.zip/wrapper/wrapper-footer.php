<?php /* Wrapper Name: Footer */ ?>
<div class="row footer-holder">
    <div class="span6" data-motopress-type="static" data-motopress-static-file="static/static-footer-text.php">
        <?php get_template_part("static/static-footer-text"); ?>
    </div>
    <div class="span3 footer-widget_1" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-1">
        <?php dynamic_sidebar("footer-sidebar-1"); ?>
    </div>
    <div class="span3 footer-widget_2" data-motopress-type="dynamic-sidebar" data-motopress-sidebar-id="footer-sidebar-2">
        <?php dynamic_sidebar("footer-sidebar-2"); ?>
    </div>
</div>
<div class="row">
    <div class="span12" data-motopress-type="static" data-motopress-static-file="static/static-footer-nav.php">
    	<?php get_template_part("static/static-footer-nav"); ?>
    </div>
</div>