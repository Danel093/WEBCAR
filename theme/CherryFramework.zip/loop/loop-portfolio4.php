<?php /* Loop Name: Portfolio 4 */ ?>
<?php // Theme Options vars
$items_count = of_get_option('items_count4');
$cols = '4cols';

require_once get_template_directory() . '/portfolio-loop.php';