<?php /* Loop Name: Portfolio 3 */ ?>
<?php // Theme Options vars
$items_count = of_get_option('items_count3');
$cols = '3cols';

require_once get_template_directory() . '/portfolio-loop.php';