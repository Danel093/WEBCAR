frameworkShortcodeAtts={
	attributes:[
			{
				label:"How many comments to show?",
				id:"num",
				help:"This is how many recent comments will be displayed."
			},
			{
				label:"Custom class",
				id:"custom_class",
				help:"Use this field if you want to use a custom class."
			}
	],
	defaultContent:"",
	shortcode:"recent_comments",
	shortcodeType: "text-replace"
};