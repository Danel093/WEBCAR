<!-- Post Meta -->
<?php get_post_metadata(); ?>
<!--// Post Meta -->